package com.jingtian.newsclient.global;

/*
 * define global constants, such as URLs
 */
public class GlobalConstants {
	
	public static final String SERVER_URL = "http://10.0.2.2:8080/zhbj";
	
	// url to get categories
	public static final String CATEGORIES_URL = SERVER_URL + "/categories.json";
	public static final String PHOTOS_URL = SERVER_URL
			+ "/photos/photos_1.json";// get image json
}
