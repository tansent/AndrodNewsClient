package com.jingtian.newsclient.utils;

import android.content.Context;

/**
 * cache utils, save content in shared preference 
 * 
 */
public class CacheUtils {

	/**
	 * set cache: key - url, value - json
	 */
	public static void setCache(String key, String value, Context ctx) {
		PrefUtils.setString(ctx, key, value);
		//cache can also be set to store in the file, file name: Md5(url), file content: json
	}

	/**
	 * get cache: key - url
	 */
	public static String getCache(String key, Context ctx) {
		return PrefUtils.getString(ctx, key, null);
	}
}
