package com.jingtian.newsclient.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

public class NoScrollViewPager extends ViewPager {

	public NoScrollViewPager(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public NoScrollViewPager(Context context) {
		super(context);
	}
	
	/**
	 * whether an event is intercepted
	 * true: end here	false: no intercept
	 * @param arg0
	 * @return
	 */
	@Override
	public boolean onInterceptTouchEvent(MotionEvent arg0) {
//		return super.onInterceptTouchEvent(arg0);
		return false;
	}
	
	/**
	 * override onTouchEvent, do nothing (to prevent scrolling)
	 * 
	 * this method has nothing to do with interception
	 */
	@Override
	public boolean onTouchEvent(MotionEvent arg0) {
		return false;
	}
}
