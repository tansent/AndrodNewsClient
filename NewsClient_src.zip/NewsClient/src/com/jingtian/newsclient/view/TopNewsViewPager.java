package com.jingtian.newsclient.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

/*
 * add some interceptions above original view pagers
 * just for TabDetailPager only
 */
public class TopNewsViewPager extends ViewPager {

	int startX;
	int startY;
	
	public TopNewsViewPager(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public TopNewsViewPager(Context context) {
		super(context);
	}


    
    
    /**
	 * ask its parent(content fragment) to intercept scroll event
	 *  1. right and first slide, do not intercept
	 *  2. left and last slide, do not intercept
	 *  3. up and down slide, do not intercept
	 *  
	 *  getParent().requestDisallowInterceptTouchEvent(false) means intercept,
	 *  which means the parent view will do its owb operation instead of letting 
	 *  children do their's
	 */
	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		switch (ev.getAction()) {
		case MotionEvent.ACTION_DOWN: //first touch screen (no use)
			getParent().requestDisallowInterceptTouchEvent(true);// let it do not move
																// to guarantee ACTION_MOVE can work
			startX = (int) ev.getRawX();
			startY = (int) ev.getRawY();
			break;
		case MotionEvent.ACTION_MOVE:

			int endX = (int) ev.getRawX();
			int endY = (int) ev.getRawY();

			if (Math.abs(endX - startX) > Math.abs(endY - startY)) {// left and right
				if (endX > startX) {// to right
					if (getCurrentItem() == 0) {// right and first slide, intercept 
						// (let the parent class do touch event in its own way)
						getParent().requestDisallowInterceptTouchEvent(false);
					}
				} else {// to left
					if (getCurrentItem() == getAdapter().getCount() - 1) {// left and last slide, intercept
																			
						getParent().requestDisallowInterceptTouchEvent(false);
					}
				}
			} else {// up and down slide, do not intercept (no use)
				getParent().requestDisallowInterceptTouchEvent(false);
			}

			break;

		default:
			break;
		}
		return super.dispatchTouchEvent(ev);
	}
}
