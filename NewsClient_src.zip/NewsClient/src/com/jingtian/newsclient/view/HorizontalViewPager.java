package com.jingtian.newsclient.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

/*
 * obsoleted
 * 
 * we use status control(OnPageChangeListener) rather than 
 * changing its event(dispatchTouchEvent) to control the sliding bar
 */
public class HorizontalViewPager extends ViewPager {

	public HorizontalViewPager(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public HorizontalViewPager(Context context) {
		super(context);
	}

	/**
     * if current page is the first page
     * ask its parent(content fragment) to intercept scroll event
     */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
    	if (getCurrentItem()!=0) {
    		getParent().requestDisallowInterceptTouchEvent(true);
		} else {
			getParent().requestDisallowInterceptTouchEvent(false);
		}
    	return super.dispatchTouchEvent(ev);
    }
}
