package com.jingtian.newsclient.view;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.jingtian.newsclient.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView;

public class RefreshListView extends ListView implements OnScrollListener,
	android.widget.AdapterView.OnItemClickListener{
	
	private static final int STATE_PULL = 0;// PULL
	private static final int STATE_RELEASE = 1;// RELEASE
	private static final int STATE_REFRESHING = 2;// REFRESHING
	
	private View mHeaderView;
	private View mFooterView;
	private int startY = -1;// set a default Y spot. (-1 means not touch screen)
	private int mHeaderViewHeight;
	private int mFooterViewHeight;
	
	private int mCurrrentState = STATE_PULL;// current status
	private TextView tvTitle;
	private TextView tvTime;
	private ImageView ivArrow;
	private ProgressBar pbProgress;
	
	private RotateAnimation animUp;
	private RotateAnimation animDown;
	
	public RefreshListView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initHeaderView();
		initFooterView();
	}

	public RefreshListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initHeaderView();
		initFooterView();
	}

	public RefreshListView(Context context) {
		super(context);
		initHeaderView();
		initFooterView();
	}
	
	/**
	 * initialize and define refresh header style
	 */
	private void initHeaderView() {
		mHeaderView = View.inflate(getContext(), R.layout.refresh_header, null);
		this.addHeaderView(mHeaderView); //add as the first header (the first, the upper)

		tvTitle = (TextView) mHeaderView.findViewById(R.id.tv_title);
		tvTime = (TextView) mHeaderView.findViewById(R.id.tv_time);
		ivArrow = (ImageView) mHeaderView.findViewById(R.id.iv_arr);
		pbProgress = (ProgressBar) mHeaderView.findViewById(R.id.pb_progress);

		mHeaderView.measure(0, 0);
		mHeaderViewHeight = mHeaderView.getMeasuredHeight();  //must measure first before it can be used

		mHeaderView.setPadding(0, -mHeaderViewHeight, 0, 0);// set padding to hide layout

		//customize arrow style 
		initArrowAnim();

		tvTime.setText("last refresh: " + getCurrentTime());
	}
		
	/**
	 * initialize and define refresh arrow animation
	 */
	private void initArrowAnim() {
		// arrow up
		animUp = new RotateAnimation(0, -180, Animation.RELATIVE_TO_SELF, 0.5f,
				Animation.RELATIVE_TO_SELF, 0.5f);
		animUp.setDuration(200);
		animUp.setFillAfter(true);

		// arrow dowm
		animDown = new RotateAnimation(-180, -360, Animation.RELATIVE_TO_SELF,
				0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		animDown.setDuration(200);
		animDown.setFillAfter(true);

	}
	
	
	private void initFooterView() {
		mFooterView = View.inflate(getContext(),
				R.layout.refresh_listview_footer, null);
		//this == listView
		this.addFooterView(mFooterView); //add to the last

		mFooterView.measure(0, 0);
		mFooterViewHeight = mFooterView.getMeasuredHeight();

		mFooterView.setPadding(0, -mFooterViewHeight, 0, 0);// hide foot view

		this.setOnScrollListener(this);
	}
	
	
	/**
	 * monitor user's touch on the screen
	 */
	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		switch (ev.getAction()) {
		case MotionEvent.ACTION_DOWN: //first touch 
			startY = (int) ev.getRawY(); //get current spot according to the screen
			break;
		case MotionEvent.ACTION_MOVE: //continue touching
			if (startY == -1) {// sometimes, MotionEvent.ACTION_DOWN does not work. Here, make sure startY can be got
				startY = (int) ev.getRawY();
			}

			if (mCurrrentState == STATE_REFRESHING) {// refreshing, then do nothing
				break;
			}

			int endY = (int) ev.getRawY();
			int dy = endY - startY;// get the pull down distance

			if (dy > 0 && getFirstVisiblePosition() == 0) {// pulling while it is the first item on screen can we pull
				int padding = dy - mHeaderViewHeight;// recalculate padding
				mHeaderView.setPadding(0, padding, 0, 0);// set current padding

				if (padding > 0 && mCurrrentState != STATE_RELEASE) {// state changes to refreshing
					mCurrrentState = STATE_RELEASE;
					refreshState();
				} else if (padding < 0 && mCurrrentState != STATE_PULL) {// state changes to releasing
					mCurrrentState = STATE_PULL;
					refreshState();
				}

				return true; //listening ends here
			}

			break;
		case MotionEvent.ACTION_UP: //release
			startY = -1;// reset

			if (mCurrrentState == STATE_RELEASE) {
				mCurrrentState = STATE_REFRESHING;// refreshing
				mHeaderView.setPadding(0, 0, 0, 0);// show refresh header
				refreshState();
			} else if (mCurrrentState == STATE_PULL) {
				mHeaderView.setPadding(0, -mHeaderViewHeight, 0, 0);// not enough distance, then hide
			}

			break;

		default:
			break;
		}
		return super.onTouchEvent(ev);
	}
	
//----------------	OnScrollListener -------------------
	@Override
	public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
		
	}

	//currently footer is showing
	private boolean isLoadingMore; //false by default
	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		if (scrollState == SCROLL_STATE_IDLE
				|| scrollState == SCROLL_STATE_FLING) { //quick scrolling

			if (getLastVisiblePosition() == getCount() - 1 && !isLoadingMore) {// 滑动到最后  
				System.out.println("last one.....");
				mFooterView.setPadding(0, 0, 0, 0);// show footer
				
				//setSelection: set current show item
				setSelection(getCount() - 1);// getCount() - 1: last visible item

				isLoadingMore = true;

				if (mListener != null) {
					mListener.onLoadMore(); //add more in footer
				}
			}
		}
	}
//------------------------------------------------------
	
	/**
	 * change state
	 */
	private void refreshState() {
		switch (mCurrrentState) {
		case STATE_PULL:
			tvTitle.setText("pulling");
			ivArrow.setVisibility(View.VISIBLE);
			pbProgress.setVisibility(View.INVISIBLE);
			ivArrow.startAnimation(animDown);
			break;
		case STATE_RELEASE:
			tvTitle.setText("releasing");
			ivArrow.setVisibility(View.VISIBLE);
			pbProgress.setVisibility(View.INVISIBLE);
			ivArrow.startAnimation(animUp);
			break;
		case STATE_REFRESHING:
			tvTitle.setText("refreshing...");
			ivArrow.clearAnimation();// animation must be clear first before refreshing
			ivArrow.setVisibility(View.INVISIBLE);
			pbProgress.setVisibility(View.VISIBLE);
			if (mListener != null) {
				mListener.onRefresh();
			}
			break;

		default:
			break;
		}
	}
	
	/**
	 * To reset and hide top refreshing bar
	 * @param success
	 * if true, then show last refresh moment
	 */
	public void onRefreshComplete(boolean success) {
		if (isLoadingMore) {// footer loading is finished...
			mFooterView.setPadding(0, -mFooterViewHeight, 0, 0);// hide footer
			isLoadingMore = false;
		} else { //header loading is finished
			mCurrrentState = STATE_PULL;
			tvTitle.setText("pull");
			ivArrow.setVisibility(View.VISIBLE);
			pbProgress.setVisibility(View.INVISIBLE);

			mHeaderView.setPadding(0, -mHeaderViewHeight, 0, 0);// hide header

			if (success) {
				tvTime.setText("last refresh: " + getCurrentTime());
			}
		}
	}
	
	/**
	 * obtain current time
	 */
	public String getCurrentTime() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return format.format(new Date());
	}
	
	
	//-------------interface for refreshing-----------------
	OnRefreshListener mListener;
	public void setOnRefreshListener(OnRefreshListener listener) {
		mListener = listener;
	}
	public interface OnRefreshListener {
		/**
		 * header refresh
		 */
		public void onRefresh();

		/**
		 * footer refresh
		 */
		public void onLoadMore();
	}
	//------------------------------------------------------
	
	//--android.widget.AdapterView.OnItemClickListener------
	OnItemClickListener mItemClickListener;
	
	@Override
	public void setOnItemClickListener(
			android.widget.AdapterView.OnItemClickListener listener) {
	  //super.setOnItemClickListener(listener);
		
		// we give our own listview (with our own onItemClick())
		super.setOnItemClickListener(this); 

		mItemClickListener = listener;
	}
	 
	/**
	 * we change the position to remove its header count
	 */
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		if (mItemClickListener != null) {
			mItemClickListener.onItemClick(parent, view, position- getHeaderViewsCount(), id);
		}
	}
	//------------------------------------------------------
	
}
