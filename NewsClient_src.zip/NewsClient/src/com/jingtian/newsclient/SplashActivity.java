package com.jingtian.newsclient;


import com.jingtian.newsclient.utils.PrefUtils;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.Animation.AnimationListener;
import android.widget.RelativeLayout;

/*
 * first page
 */
public class SplashActivity extends Activity {

	RelativeLayout rlRoot;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);

		rlRoot = (RelativeLayout) findViewById(R.id.rl_root);

		startAnim();
	}

	/**
	 * start animation
	 */
	private void startAnim() {

		// animation set
		AnimationSet set = new AnimationSet(false);

		// add rotate animation
		RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f,
				Animation.RELATIVE_TO_SELF, 0.5f);
		rotate.setDuration(1000);// animation period
		rotate.setFillAfter(true);// let this animation performs persist

		// add scale animation
		ScaleAnimation scale = new ScaleAnimation(0, 1, 0, 1, Animation.RELATIVE_TO_SELF, 0.5f,
				Animation.RELATIVE_TO_SELF, 0.5f);
		scale.setDuration(1000);// animation period
		scale.setFillAfter(true);// let this animation performs persist

		// add alpha animation
		AlphaAnimation alpha = new AlphaAnimation(0, 1);
		alpha.setDuration(2000);// animation period
		alpha.setFillAfter(true);// let this animation performs persist

		set.addAnimation(rotate);
		set.addAnimation(scale);
		set.addAnimation(alpha);

		/**
		 * set animation listener (what to do when animation starts, repeat, end)
		 */
		set.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			// when animation ends
			@Override
			public void onAnimationEnd(Animation animation) {
				jumpNextPage();
			}
		});

		rlRoot.startAnimation(set);
	}
	
	/**
	 * jump to the guide page
	 */
	private void jumpNextPage() {
		// judge if the guide pages have been set previously
		boolean userGuide = PrefUtils.getBoolean(this, "is_user_guide_showed",false);

		if (!userGuide) {
			// jump to the guide page
			startActivity(new Intent(SplashActivity.this, GuideActivity.class));
		} else {
			startActivity(new Intent(SplashActivity.this, MainActivity.class));
		}

		finish();
	}
}
