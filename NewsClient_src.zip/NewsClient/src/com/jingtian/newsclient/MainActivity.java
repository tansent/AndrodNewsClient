package com.jingtian.newsclient;


import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingFragmentActivity;
import com.jingtian.newsclient.fragment.ContentFragment;
import com.jingtian.newsclient.fragment.LeftMenuFragment;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.Window;

/*
 * this mainActivity is an empty frame layout
 */
public class MainActivity extends SlidingFragmentActivity{ //SlidingFragmentActivity

	private static final String FRAGMENT_LEFT_MENU = "fragment_left_menu";
	private static final String FRAGMENT_CONTENT = "fragment_content";
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); // cancel title bar
		
		setContentView(R.layout.activity_main);
		
		setBehindContentView(R.layout.left_menu);// set left side bar layout
		SlidingMenu slidingMenu = getSlidingMenu();// obtain side bar
		slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);// set whole screen draggable
		
		int width = getWindowManager().getDefaultDisplay().getWidth(); //obtain screen width
		
		//use current development parameters to adapt the view
		slidingMenu.setBehindOffset( width  * 200/320 );// set reserved space for main page

		initFragment();
	}
	
	/**
	 * set the structure of the initial empty page
	 */
	private void initFragment() {
		FragmentManager fm = getSupportFragmentManager();
		FragmentTransaction transaction = fm.beginTransaction();// begin transaction
		
		// replace empty framelayout with fragment
		transaction.replace(R.id.fl_left_menu, new LeftMenuFragment(),
				FRAGMENT_LEFT_MENU);//name it (easy access for future - fm.findFragmentByTag(arg0))
		transaction.replace(R.id.fl_content, new ContentFragment(),
				FRAGMENT_CONTENT);

		transaction.commit();// commit
		// Fragment leftMenuFragment = fm.findFragmentByTag(FRAGMENT_LEFT_MENU);
	}

	/**
	 * obtain side bar
	 * @return
	 */
	public LeftMenuFragment getLeftMenuFragment() {
		FragmentManager fm = getSupportFragmentManager();
		LeftMenuFragment fragment = (LeftMenuFragment) fm
				.findFragmentByTag(FRAGMENT_LEFT_MENU);

		return fragment;
	}
	
	/**
	 * obtain the fragment of the main page
	 * @return
	 */
	public ContentFragment getContentFragment() {
		FragmentManager fm = getSupportFragmentManager();
		ContentFragment fragment = (ContentFragment) fm
				.findFragmentByTag(FRAGMENT_CONTENT);

		return fragment;
	}
}
