package com.jingtian.newsclient;

import java.util.ArrayList;

import com.jingtian.newsclient.utils.DensityUtil;
import com.jingtian.newsclient.utils.PrefUtils;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

/*
 * introduction page after splash
 */
public class GuideActivity extends Activity {

	private static final int[] mImageIds = new int[] { R.drawable.guide_1, R.drawable.guide_2, R.drawable.guide_3 };

	/**
	 * ViewPager can let one activity be like several activities(easy to realize
	 * sliding) (android.support.v4)
	 */
	private ViewPager vpGuide;
	private ArrayList<ImageView> mImageViewList;
	private Button btnStart;
	private LinearLayout llPointGroup;// small spots group
	private View viewRedPoint;// red spot
	private int mPointWidth;// distance between spots

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_NO_TITLE);// request no title bar
														// for this activity
		setContentView(R.layout.activity_guide);
		vpGuide = (ViewPager) findViewById(R.id.vp_guide);
		btnStart = (Button) findViewById(R.id.btn_start);
		llPointGroup = (LinearLayout) findViewById(R.id.ll_point_group);
		viewRedPoint = findViewById(R.id.view_red_point);

		initViews();
		// instantiate mImageViewList first
		vpGuide.setAdapter(new MyPagerAdapter());
		vpGuide.setOnPageChangeListener(new GuidePageListener());
		
		btnStart.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// after user has seen all ads and clicked the button, set preference to true
				PrefUtils.setBoolean(GuideActivity.this,
						"is_user_guide_showed", true);

				// to home page
				startActivity(new Intent(GuideActivity.this, MainActivity.class));
				finish();
			}
		});
	}

	private void initViews() {
		mImageViewList = new ArrayList<ImageView>();

		// initialize 3 pages of the guidance process
		for (int i = 0; i < mImageIds.length; i++) {
			ImageView image = new ImageView(this);
			image.setBackgroundResource(mImageIds[i]);// set background for each
														// image
			mImageViewList.add(image);
		}

		// initialize spot group
		for (int i = 0; i < mImageIds.length; i++) {
			View point = new View(this);
			point.setBackgroundResource(R.drawable.shape_point_gray);// set grey as the default ones

			int px_diameter = DensityUtil.dip2px(getApplicationContext(), 10);
			
			LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(px_diameter, px_diameter); // set spot size
			if (i > 0) {
				params.leftMargin = px_diameter;// set spot distance (from 2nd spot)
			}

			point.setLayoutParams(params);

			llPointGroup.addView(point);// add spot to the layout
		}
		
		/**
		 * invoke after the layout loading is finished.
		 * (left margin of the points cannot be written directly in onCreate() method.
		 * Because at that time, the layout is loading)
		 *
		 * Here, obtaining the view tree, to monitor when the layout gets finished loading
		 */
		llPointGroup.getViewTreeObserver().addOnGlobalLayoutListener(
				new OnGlobalLayoutListener() {

					// onGlobalLayout() invoked after the layout is loaded
					//to get "mPointWidth"
					@Override
					public void onGlobalLayout() {
						//remove this listener to avoid invoking multiply times
						llPointGroup.getViewTreeObserver()
								.removeGlobalOnLayoutListener(this);
						mPointWidth = llPointGroup.getChildAt(1).getLeft()
								- llPointGroup.getChildAt(0).getLeft();
					}
				});
	}

	
	/*
	 * PagerAdapter: from ipv4
	 * to link to the source file, we need to delete current library first and then 
	 * to import system's ipv4 library again from the libs folder
	 * 
	 */
	class MyPagerAdapter extends PagerAdapter {

		/**
		 * how many pages
		 */
		@Override
		public int getCount() {
			return mImageIds.length;
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		/**
		 * when creating the page
		 */
		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			container.addView(mImageViewList.get(position));
			return mImageViewList.get(position);
		}

		/**
		 * when destroying the page
		 */
		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView((View) object);
		}

	}
	
	
	/*
	 * monitor operations of the view pager 
	 */
	class GuidePageListener implements OnPageChangeListener{

		/**
		 * when scrolling (accuracy is about 0.1s)
		 * 
		 * positionOffset: % of scrolling(0 -> 0)   
		 * position: which page is it
		 */
		@Override
		public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
			
			int len = (int) (mPointWidth * positionOffset) + position * mPointWidth;
			
			//convert View to RelativeLayout so that it can set params
			RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) viewRedPoint
					.getLayoutParams();// obtain the layout of the red spot
			params.leftMargin = len;// set left margin

			viewRedPoint.setLayoutParams(params);// as scrolling, set red spot position
		}

		/**
		 * when the page is selected
		 */
		@Override
		public void onPageSelected(int position) {
			
			if (position == mImageIds.length - 1) {// last page
				btnStart.setVisibility(View.VISIBLE);// show button
			} else {
				btnStart.setVisibility(View.INVISIBLE);
			}
		}

		/**
		 * when scroll state changed
		 */
		@Override
		public void onPageScrollStateChanged(int state) {
			
		}
		
	}
}
