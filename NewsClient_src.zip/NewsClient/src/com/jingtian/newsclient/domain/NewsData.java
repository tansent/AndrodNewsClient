package com.jingtian.newsclient.domain;

import java.util.ArrayList;


/*
 * encapsulate network information
 * 
 * select the information we need to encapsulate (no need to encapsulate every fields)
 * as long as the field that is needed once, we should include
 * 
 * The names we use here must be the same as the name in the network String(the server side)
 */
public class NewsData {

	// using HiJson to get the fields name
	
	public int retcode;
	public ArrayList<NewsMenuData> data;
	
	// side bar data class
	public class NewsMenuData {
		public String id;
		public String title;
		public int type;
		public String url;

		public ArrayList<NewsTabData> children; //news center information

		@Override
		public String toString() {
			return "NewsMenuData [title=" + title + ", children=" + children
					+ "]";
		}
	}
	
		// 11 sub pages under the news center section
		public class NewsTabData {
			public String id;
			public String title;
			public int type;
			public String url;

			@Override
			public String toString() {
				return "NewsTabData [title=" + title + "]";
			}
		}
		
		@Override
		public String toString() {
			return "NewsData [data=" + data + "]";
		}
	
}
