package com.jingtian.newsclient.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/*
 * Fragment: part of activity
 * 
 * this BaseFragment class contains nothing, only an empty framework
 */
public abstract class BaseFragment extends Fragment{

	public Activity mActivity;
	
	// create fragment
		@Override
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			//this time, we have a very basic activity without our own logics
			//getActivity() to get main activity
			mActivity = getActivity(); 
		}

		// create layout of our own fragment
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			return initViews();
		}

		// when activity has completed loading layout
		@Override
		public void onActivityCreated(Bundle savedInstanceState) {
			super.onActivityCreated(savedInstanceState);

			initData();
		}
		
		// subclass to realize its own layout
		public abstract View initViews();

		// initialize data. get data from servers...
		public void initData() {
			// here, we only need to load a layout
		}
}
