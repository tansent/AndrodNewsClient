package com.jingtian.newsclient.fragment;


import java.util.ArrayList;

import com.jingtian.newsclient.R;
import com.jingtian.newsclient.base.BasePager;
import com.jingtian.newsclient.base.impl.GovAffairsPager;
import com.jingtian.newsclient.base.impl.HomePager;
import com.jingtian.newsclient.base.impl.NewsCenterPager;
import com.jingtian.newsclient.base.impl.SettingPager;
import com.jingtian.newsclient.base.impl.SmartServicePager;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

/*
 * main page
 */
public class ContentFragment extends BaseFragment{

	//Using the XUtils to add anotation
	@ViewInject(R.id.rg_group)
	private RadioGroup rgGroup;
	
	@ViewInject(R.id.vp_content)
	private ViewPager mViewPager; //NoScrollViewPager.java
	
	private ArrayList<BasePager> mPagerList;
	
	@Override
	public View initViews() {
		View view = View.inflate(mActivity, R.layout.fragment_content, null);
		
		// rgGroup = (RadioGroup) view.findViewById(R.id.rg_group);
		ViewUtils.inject(this, view); // inject view and events (equals to findViewById - XUtils)
		return view;
	}

	@Override
	public void initData() {
		rgGroup.check(R.id.rb_home); //set home page as the default selection
		
		// initialize 5 pages here
		mPagerList = new ArrayList<BasePager>();
		
		mPagerList.add(new HomePager(mActivity));
		mPagerList.add(new NewsCenterPager(mActivity));
		mPagerList.add(new SmartServicePager(mActivity));
		mPagerList.add(new GovAffairsPager(mActivity));
		mPagerList.add(new SettingPager(mActivity));
		
		//view pager's adapter only set static framework, not data
		mViewPager.setAdapter(new ContentAdapter());
		
		// listen RadioGroup's click(checked event)
		rgGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {

		/**
		 * radio button's onClick event
		 * 
		 * @params
		 * 2nd - checkId: id of the checked item
		 */
		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {
			switch (checkedId) {
			case R.id.rb_home:
				// mViewPager.setCurrentItem(0);// turn to index page
				
				//constructor will invoke
				mViewPager.setCurrentItem(0, false);// turn to index page without sliding animation
				break;
			case R.id.rb_news:
				mViewPager.setCurrentItem(1, false);
				break;
			case R.id.rb_smart:
				mViewPager.setCurrentItem(2, false);
				break;
			case R.id.rb_gov:
				mViewPager.setCurrentItem(3, false);
				break;
			case R.id.rb_setting:
				mViewPager.setCurrentItem(4, false);
				break;

			default:
				break;
				}
			}
		});
		
		/**
		 * when page of the viewPager changes
		 * to prevent preloading feature of view-pager
		 * we can initialize our data either here, or in the onclick(oncheck) listener
		 */
		mViewPager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int position) {
				mPagerList.get(position).initData();// initialize the current page
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}
		});

		mPagerList.get(0).initData();// initialize the first page
		
	}
	
	/*
	 * pagerAdapter needs a separate data and view
	 * thus, there are a initData and initView
	 */
	class ContentAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return mPagerList.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		/**
		 * Initialize data when loading
		 * 
		 * here, we should only initialize STATIC view.
		 * 
		 * Due to its pre-loading machnism, pre and post page's data will
		 * also get loaded, which can cause some logical mistakes,
		 * such as in some pages, we want switch off, yet in other pages,
		 * we want them on
		 */
		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			BasePager pager = mPagerList.get(position);
			container.addView(pager.mRootView);
//			 pager.initData();// initialize data for both this page and next page.... 
			//to prevent preloading, move "pager.initData()" to onPageSelected
			return pager.mRootView;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView((View) object);
		}

	}
	
	
	/**
	 * get news sub-window
	 * 
	 * @return
	 */
	public NewsCenterPager getNewsCenterPager() {
		return (NewsCenterPager) mPagerList.get(1);
	}
	
}
