package com.jingtian.newsclient.fragment;

import java.util.ArrayList;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jingtian.newsclient.MainActivity;
import com.jingtian.newsclient.R;
import com.jingtian.newsclient.base.impl.NewsCenterPager;
import com.jingtian.newsclient.domain.NewsData;
import com.jingtian.newsclient.domain.NewsData.NewsMenuData;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

/*
 * left side
 */
public class LeftMenuFragment extends BaseFragment{

	private ArrayList<NewsMenuData> mMenuList;
	private MenuAdapter mAdapter;
	
	@ViewInject(R.id.lv_list)
	private ListView lvList;
	
	private int mCurrentPos;// current clicked item in the side bar list
	
	/**
	 * set the framework
	 */
	@Override
	public View initViews() {
		View view = View.inflate(mActivity, R.layout.fragment_left_menu, null);
		
		ViewUtils.inject(this, view); // == findviewbyid
		return view;
	}
	
	
	// get information from server
	public void setMenuData(NewsData data) {
//		 System.out.println("侧边栏拿到数据啦:" + data);
		mMenuList = data.data;
		mAdapter = new MenuAdapter();
		lvList.setAdapter(mAdapter);
	}
	
	/**
	 * from BaseFragment, when the fragment is created, initData() will be invoked
	 */
	@Override
	public void initData() {
		
		lvList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				mCurrentPos = position;
				
				//update adapter(update list)
				mAdapter.notifyDataSetChanged(); //getView()

				setCurrentMenuDetailPager(position);

				toggleSlidingMenu();// hide side bar
			}
		});
	}
	
	/**
	 * side bar adapter
	 * 
	 */
	class MenuAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return mMenuList.size();
		}
		
		//invoke first time and every time when "notifyDataSetChanged()" occurs
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = View.inflate(mActivity, R.layout.list_menu_item, null);
			TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
			
			NewsMenuData newsMenuData = getItem(position); //change the return value of getitem
			tvTitle.setText(newsMenuData.title);

			if (mCurrentPos == position) {// the view that is selected == this view
				//selector judged by the enable trait, because it can last compare to press trait
				
				// red
				tvTitle.setEnabled(true); 
			} else {
				// white
				tvTitle.setEnabled(false);
			}

			return view;
		}

		@Override
		public NewsMenuData getItem(int position) {
			return mMenuList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

	}
	
	
	/**
	 * set sub window detail, to decide which sub window to show
	 * 
	 * @param position
	 */
	protected void setCurrentMenuDetailPager(int position) {
		MainActivity mainUi = (MainActivity) mActivity;
		ContentFragment fragment = mainUi.getContentFragment();// mainActivity's content fragment
		NewsCenterPager pager = fragment.getNewsCenterPager();// content fragment's news sub page
		pager.setCurrentMenuDetailPager(position);// set current news window page
		
		/*
		 * setCurrentMenuDetailPager() method cannot be static,
		 * because the static controller does not work.
		 * Once the function static, the controller must be static   
		 */
//		NewsCenterPager.setCurrentMenuDetailPager(position);
	}
	
	
	/**
	 * switch SlidingMenu's state
	 * 
	 */
	protected void toggleSlidingMenu() {
		MainActivity mainUi = (MainActivity) mActivity;
		SlidingMenu slidingMenu = mainUi.getSlidingMenu();
		
		slidingMenu.toggle();// hide -> show  /  show -> hide
	}
	
}
