package com.jingtian.newsclient.base;


import java.util.ArrayList;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jingtian.newsclient.MainActivity;
import com.jingtian.newsclient.R;

import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

/*
 * the common part of the center pages
 */
public class BasePager {
	
	//those fields cannot be static(because they are constantly changing)
	public Activity mActivity; // for later use(context)
	
	public View mRootView;// layout 
	
	public TextView tvTitle;// title
	
	public FrameLayout flContent;// middle content   (cannot be static)
	
	public ImageButton btnMenu;// upper-left radios 
	
	public ImageButton btnPhoto;// list-grid change button
	
	public BasePager(Activity activity) {
		mActivity = activity;
		initViews();
	}
	
	/**
	 * initialize layout
	 */
	public void initViews() {
		mRootView = View.inflate(mActivity, R.layout.base_pager, null);

		tvTitle = (TextView) mRootView.findViewById(R.id.tv_title);
		flContent = (FrameLayout) mRootView.findViewById(R.id.fl_content);
		btnMenu = (ImageButton) mRootView.findViewById(R.id.btn_menu);
		btnPhoto = (ImageButton) mRootView.findViewById(R.id.btn_photo);

		btnMenu.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				toggleSlidingMenu();
			}
		});
	}
	
	/**
	 * initialize data
	 */
	public void initData() {

	}
	
	/**
	 * switch SlidingMenu's state
	 * 
	 */
	protected void toggleSlidingMenu() {
		MainActivity mainUi = (MainActivity) mActivity;
		SlidingMenu slidingMenu = mainUi.getSlidingMenu();
		
		slidingMenu.toggle();// hide -> show  /  show -> hide
	}
	
	/**
	 * whether to include sliding bar or not 
	 * 
	 * @param enable
	 */
	public void setSlidingMenuEnable(boolean enable) {
		MainActivity mainUi = (MainActivity) mActivity;

		SlidingMenu slidingMenu = mainUi.getSlidingMenu(); //main activity extends from slidingActivity

		if (enable) {
			//have sliding bar 
			slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
		} else {
			//not have sliding bar 
			slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
		}
	}
	
}
