package com.jingtian.newsclient.base;

import java.util.ArrayList;

import com.google.gson.Gson;

import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;

import com.jingtian.newsclient.NewsDetailActivity;
import com.jingtian.newsclient.R;
import com.jingtian.newsclient.domain.NewsData.NewsTabData;
import com.jingtian.newsclient.domain.TabData;
import com.jingtian.newsclient.domain.TabData.TabNewsData;
import com.jingtian.newsclient.domain.TabData.TopNewsData;
import com.jingtian.newsclient.global.GlobalConstants;
import com.jingtian.newsclient.utils.CacheUtils;
import com.jingtian.newsclient.utils.PrefUtils;
import com.jingtian.newsclient.view.RefreshListView;
import com.jingtian.newsclient.view.RefreshListView.OnRefreshListener;
import com.jingtian.newsclient.view.TopNewsViewPager;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.viewpagerindicator.CirclePageIndicator;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView.ScaleType;
import android.widget.ListView;

/*
 * each sliding menu page under the news tab window
 */
public class TabDetailPager extends BaseMenuDetailPager implements OnPageChangeListener{

	NewsTabData mTabData;
	private TextView tvText;
	private String mUrl;
	private TabData mTabDetailData;
	
	@ViewInject(R.id.vp_news)
	private TopNewsViewPager mViewPager; //define and findviewById at the same time
	
	@ViewInject(R.id.tv_title)
	private TextView tvTitle;// headlines title
	private ArrayList<TopNewsData> mTopNewsList;// headlines set
	
	//from ViewPagerLibrary(external project)
	@ViewInject(R.id.indicator)
	private CirclePageIndicator mIndicator; //headline spots 
	
	@ViewInject(R.id.lv_list) //initialization (new)
	private RefreshListView lvList;// news list (progress bar head view added)
	
	private ArrayList<TabNewsData>  mNewsList;// headlines set
	private NewsAdapter mNewsAdapter;
	
	private Handler mHandler; //use recursive on tap window to auto-move

	public TabDetailPager(Activity activity, NewsTabData newsTabData) {
		super(activity);
		mTabData = newsTabData;
		
		mUrl = GlobalConstants.SERVER_URL + mTabData.url;
	}

	@Override
	public View initViews() {
		View view = View.inflate(mActivity, R.layout.tab_detail_pager, null);
		// load list view header layout
		View headerView = View.inflate(mActivity, R.layout.list_header_top_news,
				null);

		//only after inject can we use annotation to findView
		ViewUtils.inject(this, view);  
//		mViewPager.setOnPageChangeListener(this); //set listener(OnPageChangeListener)
		
		ViewUtils.inject(this, headerView);

		// set header view to listview
		//header view can be seen as part of the list without being reuse
		lvList.addHeaderView(headerView); //(second head view)
		
		//defined in RefreshListView
		lvList.setOnRefreshListener(new OnRefreshListener() {
			
			@Override
			public void onRefresh() { //header refresh new data
				getDataFromServer();
			}
			
			@Override
			public void onLoadMore() { //footer adds new data
				if (mFooterLoadingUrl != null) {
					getMoreDataFromServer();
				} else {
					Toast.makeText(mActivity, "No more news", Toast.LENGTH_SHORT)
							.show();
					lvList.onRefreshComplete(false);// fold layout
				}	
			}
		});
		
		lvList.setOnItemClickListener(new OnItemClickListener() {
			/**
			 * initially, position includes headers and footers, but we overwrite
			 * onItemClick() method in our own RefreshListView(ListView),
			 * which has removed headers. So now, the position has the same sequence as
			 * the list does
			 */
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//				System.out.println(position + " is clicked");
				
				// news id examples: 35311,34221,34234,34342
				// record news read status locally 
				String ids = PrefUtils.getString(mActivity, "read_ids", "");
				String readId = mNewsList.get(position).id; //id here is not the id from method
				if (!ids.contains(readId)) { //no repeat storage
					ids = ids + readId + ",";
					PrefUtils.setString(mActivity, "read_ids", ids);
				}

				// mNewsAdapter.notifyDataSetChanged(); //this will refresh the whole list
				changeReadState(view);// specific item refresh(view means the item clicked)
				
				// jump to the news page
				Intent intent = new Intent();
				intent.setClass(mActivity, NewsDetailActivity.class);
				intent.putExtra("url", mNewsList.get(position).url);
				mActivity.startActivity(intent);
			}
		});
		
		return view;
	}

	/**
	 * initialize data
	 * use cache first then get data from server
	 */
	@Override
	public void initData() {
		
		String cache = CacheUtils.getCache(mUrl, mActivity);

		if (!TextUtils.isEmpty(cache)) {
			parseData(cache, false);
		}
		
		getDataFromServer();
	}
	
	/**
	 * obtain data from server
	 */
	private void getDataFromServer() {
		HttpUtils utils = new HttpUtils();
		utils.send(HttpMethod.GET, mUrl, new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				String result = (String) responseInfo.result; //result is a json string
				System.out.println("页签详情页返回结果:" + result);

				parseData(result,false); // parse header data
				 
				lvList.onRefreshComplete(true);
				
				// set cache
				CacheUtils.setCache(mUrl, result, mActivity);
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				Toast.makeText(mActivity, msg, Toast.LENGTH_SHORT).show();
				error.printStackTrace();
				
				lvList.onRefreshComplete(false);
			}
		});
	}
	
	private String mFooterLoadingUrl;// footer loading more URL
	/**
	 * loading footer data
	 */
	private void getMoreDataFromServer() {
		HttpUtils utils = new HttpUtils();
		utils.send(HttpMethod.GET, mFooterLoadingUrl, new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				String result = (String) responseInfo.result;

				parseData(result, true); // parse footer data

				lvList.onRefreshComplete(true);
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				Toast.makeText(mActivity, msg, Toast.LENGTH_SHORT).show();
				error.printStackTrace();
				lvList.onRefreshComplete(false);
			}
		});
	}

	/**
	 * parse json data obtained from the internet 
	 * and store them in classes
	 * @param result
	 * url needed to parse
	 * @param isLoadingFooter
	 * true: footer loading data  false: header loading data
	 */
	protected void parseData(String result, boolean isLoadingFooter) {
		Gson gson = new Gson();
		mTabDetailData = gson.fromJson(result, TabData.class);
		System.out.println("页签详情解析:" + mTabDetailData);

		// get loading more link(for footer)
		String more = mTabDetailData.data.more;
		if (!TextUtils.isEmpty(more)) {
			mFooterLoadingUrl = GlobalConstants.SERVER_URL + more;
		} else {
			mFooterLoadingUrl = null;
		}
			
		if (!isLoadingFooter) { //refresh in header
			mTopNewsList = mTabDetailData.data.topnews; //prior to set adapter
			
			mNewsList = mTabDetailData.data.news;
			
			//always judge if-null first
			if (mTopNewsList!= null) {
				mViewPager.setAdapter(new TopNewsAdapter()); // adapter runs in main thread
				
				//those dots under the picture
				mIndicator.setViewPager(mViewPager);
				mIndicator.setSnap(true);// supporting snap effects
				mIndicator.setOnPageChangeListener(this); //set indicator's listener
				mIndicator.onPageSelected(0);// force indicator to start at 0 position(by default, it will record)
				
				tvTitle.setText(mTopNewsList.get(0).title); //set the first one before touching screen
			}
			
			if (mNewsList != null) {
				mNewsAdapter = new NewsAdapter();
				lvList.setAdapter(mNewsAdapter);
			}
			
			// auto-play tab window
			if (mHandler == null) {
				mHandler = new Handler() {
					public void handleMessage(android.os.Message msg) {
						int currentItem = mViewPager.getCurrentItem();

						if (currentItem < mTopNewsList.size() - 1) { //boundary
							currentItem++;
						} else {
							currentItem = 0;
						}

						mViewPager.setCurrentItem(currentItem);// next page
						mHandler.sendEmptyMessageDelayed(0, 3000);//continue sending
					};
				};

				mHandler.sendEmptyMessageDelayed(0, 3000);// send delay message to handler in 3s
			}
		}
		else {// loading footer
			ArrayList<TabNewsData> news = mTabDetailData.data.news;
			mNewsList.addAll(news); //add new data to the end of the list
			mNewsAdapter.notifyDataSetChanged();
		}
	}
	
	
	/**
	 * to keep the tab-window still while touching
	 * need to set image.setOnTouchListener(new TopNewsTouchListener()); in adapter
	 * 
	 */
	class TopNewsTouchListener implements OnTouchListener {

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				System.out.println("按下");
				mHandler.removeCallbacksAndMessages(null);// remove all messages in handler
				// mHandler.postDelayed(new Runnable() {
				//
				// @Override
				// public void run() {
				//
				// }
				// }, 3000);
				break;
			case MotionEvent.ACTION_CANCEL:
				System.out.println("事件取消");
				mHandler.sendEmptyMessageDelayed(0, 3000);
				break;
			case MotionEvent.ACTION_UP:
				System.out.println("抬起");
				mHandler.sendEmptyMessageDelayed(0, 3000);
				break;

			default:
				break;
			}

			return true;
		}

	}
	
	/**
	 * top news (headlines)adapter (viewPager)
	 */
	class TopNewsAdapter extends PagerAdapter {
  
		//From XUtils. for loading images
		private BitmapUtils utils;
		public TopNewsAdapter() {
			//define BitmapUtils
			utils = new BitmapUtils(mActivity);
			
			// set default image background
			utils.configDefaultLoadingImage(R.drawable.topnews_item_default);
		}

		@Override
		public int getCount() {
			return mTabDetailData.data.topnews.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			ImageView image = new ImageView(mActivity);
			
			// fill the component to the whole screen
			image.setScaleType(ScaleType.FIT_XY);

			TopNewsData topNewsData = mTopNewsList.get(position);
			utils.display(image, topNewsData.topimage);// using bitmap utils to load url image

			container.addView(image);
			
//			image.setOnClickListener(new ...); //only setOnClickListener or setOnTouchListener
			image.setOnTouchListener(new TopNewsTouchListener());//set listener
			
			return image;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView((View) object);
		}
	}
	
	
	/**
	 * news list adapter
	 * 
	 */
	class NewsAdapter extends BaseAdapter {

		private BitmapUtils utils;

		public NewsAdapter() {
			utils = new BitmapUtils(mActivity);
			utils.configDefaultLoadingImage(R.drawable.pic_item_list_default);
		}

		@Override
		public int getCount() {
			return mNewsList.size();
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				convertView = View.inflate(mActivity, R.layout.list_news_item,
						null);
				holder = new ViewHolder();
				holder.ivPic = (ImageView) convertView
						.findViewById(R.id.iv_pic);
				holder.tvTitle = (TextView) convertView
						.findViewById(R.id.tv_title);
				holder.tvDate = (TextView) convertView
						.findViewById(R.id.tv_date);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			TabNewsData item = getItem(position);

			holder.tvTitle.setText(item.title);
			holder.tvDate.setText(item.pubdate);

			utils.display(holder.ivPic, item.listimage);
			
			//judge if the news have been read
			String ids = PrefUtils.getString(mActivity, "read_ids", "");
			if (ids.contains(getItem(position).id)) {
				holder.tvTitle.setTextColor(Color.GRAY);
			} else {
				holder.tvTitle.setTextColor(Color.BLACK);
			}

			return convertView;
		}

		@Override
		public TabNewsData getItem(int position) {
			return mNewsList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}
	}
	static class ViewHolder {
		public TextView tvTitle;
		public TextView tvDate;
		public ImageView ivPic;
	}
	
	/**
	 * change color of the specific read item(use this method instead of notifyDataSetChange)
	 * this method only perform a particular change of the whole list to avoid total refresh
	 */
	private void changeReadState(View view) {
		TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
		tvTitle.setTextColor(Color.GRAY);
	}
	
	//-------OnPageChangeListener----------------

	@Override
	public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
		
	}
	
	@Override
	public void onPageScrollStateChanged(int arg0) {
		
	}

	/**
	 * this function will only invoke when the page changes
	 */
	@Override
	public void onPageSelected(int position) {
		//tvTitle is not part of the viewPager, it should be set here, rather than in the adapter 
		TopNewsData topNewsData = mTopNewsList.get(position);
		tvTitle.setText(topNewsData.title);
		
	}
	//-----------------------------------------
	
}
