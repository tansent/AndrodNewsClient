package com.jingtian.newsclient.base.submenudetail;

import java.util.ArrayList;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jingtian.newsclient.MainActivity;
import com.jingtian.newsclient.R;
import com.jingtian.newsclient.base.BaseMenuDetailPager;
import com.jingtian.newsclient.base.TabDetailPager;
import com.jingtian.newsclient.domain.NewsData.NewsTabData;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.viewpagerindicator.TabPageIndicator;

import android.app.Activity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.ViewGroup;


/**
 * 菜单详情页-新闻
 * 
 */
public class NewsMenuDetailPager extends BaseMenuDetailPager implements OnPageChangeListener{

//	public NewsMenuDetailPager(Activity activity) {
//		super(activity);
//	}

	private ViewPager mViewPager;

	//TabDetailPager = NewsTabData + Activity
	private ArrayList<TabDetailPager> mPagerList;

	private ArrayList<NewsTabData> mNewsTabData;// sub tabs of the sub window page from the server 

	//control tags (dispatchTouchEvent is override to prevent scrolling)
	private TabPageIndicator mIndicator;

	/**
	 * we use the constructor with data
	 * @param activity
	 * @param children
	 */
	public NewsMenuDetailPager(Activity activity,
			ArrayList<NewsTabData> children) {
		super(activity);

		mNewsTabData = children; //11 here, get from online
	}

	@Override
	public View initViews() {
		View view = View.inflate(mActivity, R.layout.news_menu_detail, null);
		mViewPager = (ViewPager) view.findViewById(R.id.vp_menu_detail);
		
		ViewUtils.inject(this, view); //inject first, so notation can be used(XUtils)
		
		mIndicator = (TabPageIndicator)view.findViewById(R.id.indicator);
        
//		//to monitor the state of the pager
//		mViewPager.setOnPageChangeListener(this);
		//when there is an indicator, set listener to viewPagerIndicator
		mIndicator.setOnPageChangeListener(this);
		
		return view;
		
	}

	/*
	 * invoke in NewsCenterPager line 147 (under method: setCurrentMenuDetailPager)
	 */
	@Override
	public void initData() {
		mPagerList = new ArrayList<TabDetailPager>();

		// initialize tab data
		for (int i = 0; i < mNewsTabData.size(); i++) {
			TabDetailPager pager = new TabDetailPager(mActivity, mNewsTabData.get(i));
			mPagerList.add(pager);
		}

		mViewPager.setAdapter(new MenuDetailAdapter());
		
		/**
		 * to connect viewPager and Indicator
		 */
		mIndicator.setViewPager(mViewPager); //after view-pager's adapter is set can this function being invoked
	}
	
	/**
	 * to next sub menu (from XUtils)
	 * @param view
	 */
	@OnClick(R.id.btn_next)
	public void nextPage(View view){
		int currentItem = mViewPager.getCurrentItem();
		
		//change view pager to current position
		mViewPager.setCurrentItem(++currentItem); //++ must be first
	}
	

	/*
	 * pagerAdapter needs to separate data and view
	 */
	class MenuDetailAdapter extends PagerAdapter {

		/**
		 * return title of the view pager
		 */
		@Override
		public CharSequence getPageTitle(int position) {
			return mNewsTabData.get(position).title;
		}
		
		@Override
		public int getCount() {
			return mPagerList.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			TabDetailPager pager = mPagerList.get(position);
			container.addView(pager.mRootView);
			pager.initData(); //later change !!!
			return pager.mRootView;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView((View) object);
		}
	}


	//--------------OnPageChangeListener
	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * when page is selected
	 */
	@Override
	public void onPageSelected(int enable) {
		MainActivity mainActivity  = (MainActivity) mActivity;
		
		SlidingMenu slidingMenu = mainActivity.getSlidingMenu();
		if (enable == 0) {
			//have sliding bar 
			slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
		} else {
			//not have sliding bar 
			slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
		}
	}

}
