package com.jingtian.newsclient.base;

import android.app.Activity;
import android.view.View;

/*
 * a base structure for news center's sub page
 */
public abstract class BaseMenuDetailPager {

	public Activity mActivity;

	public View mRootView;// basic root view

	public BaseMenuDetailPager(Activity activity) {
		mActivity = activity;
		mRootView = initViews();
	}

	/**
	 * initialize view
	 */
	public abstract View initViews();

	/**
	 * initialize data
	 */
	public void initData() {

	}
}
