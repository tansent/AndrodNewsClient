package com.jingtian.newsclient.base.impl;

import com.jingtian.newsclient.base.BasePager;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;


/*
 * setting
 */
public class SettingPager extends BasePager {

	public SettingPager(Activity activity) {
		super(activity);
	}

	@Override
	public void initData() {
		
		tvTitle.setText("设置");
		btnMenu.setVisibility(View.GONE);// hide button of the title bar
		setSlidingMenuEnable(false);// no side bar

		TextView text = new TextView(mActivity);
		text.setText("设置");
		text.setTextColor(Color.RED);
		text.setTextSize(25);
		text.setGravity(Gravity.CENTER);

		// add concrete view to FrameLayout
		flContent.addView(text);
	}

}
