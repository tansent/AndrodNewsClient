package com.jingtian.newsclient.base.impl;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jingtian.newsclient.base.BasePager;

/*
 * home page
 */
public class HomePager extends BasePager {

	//activity here is main activity
	public HomePager(Activity activity) {
		super(activity);
	}

	@Override
	public void initData() {
		
		tvTitle.setText("智慧北京");// alter title
		btnMenu.setVisibility(View.GONE);// hide button of the title bar
		setSlidingMenuEnable(false);//no side bar

		TextView text = new TextView(mActivity);
		text.setText("首页");
		text.setTextColor(Color.RED);
		text.setTextSize(25);
		text.setGravity(Gravity.CENTER);

		// add concrete view to FrameLayout
		flContent.addView(text);
	}

}
