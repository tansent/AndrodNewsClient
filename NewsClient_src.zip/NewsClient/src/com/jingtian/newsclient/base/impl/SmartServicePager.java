package com.jingtian.newsclient.base.impl;

import com.jingtian.newsclient.base.BasePager;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;


/*
 * Smart service
 */
public class SmartServicePager extends BasePager {

	public SmartServicePager(Activity activity) {
		super(activity);
	}

	@Override
	public void initData() {

		tvTitle.setText("生活");
		setSlidingMenuEnable(true);// no side bar

		TextView text = new TextView(mActivity);
		text.setText("智慧服务");
		text.setTextColor(Color.RED);
		text.setTextSize(25);
		text.setGravity(Gravity.CENTER);

		//add concrete view to FrameLayout
		flContent.addView(text);
	}

}
