package com.jingtian.newsclient.base.impl;

import java.util.ArrayList;

import com.google.gson.Gson;
import com.jingtian.newsclient.MainActivity;
import com.jingtian.newsclient.base.BaseMenuDetailPager;
import com.jingtian.newsclient.base.BasePager;
import com.jingtian.newsclient.base.submenudetail.InteractMenuDetailPager;
import com.jingtian.newsclient.base.submenudetail.NewsMenuDetailPager;
import com.jingtian.newsclient.base.submenudetail.PhotoMenuDetailPager;
import com.jingtian.newsclient.base.submenudetail.TopicMenuDetailPager;
import com.jingtian.newsclient.domain.NewsData;
import com.jingtian.newsclient.domain.NewsData.NewsMenuData;
import com.jingtian.newsclient.fragment.LeftMenuFragment;
import com.jingtian.newsclient.global.GlobalConstants;
import com.jingtian.newsclient.utils.CacheUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

import android.app.Activity;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

/*
 * news center (contains 4 sub windows)
 */
public class NewsCenterPager extends BasePager {

	private static ArrayList<BaseMenuDetailPager> subNewsPagers;// 4 sub window for news center
	private NewsData mNewsData;

	public NewsCenterPager(Activity activity) {
		super(activity);
	}

	@Override
	public void initData() {
		tvTitle.setText("新闻");
//		// add concrete view to FrameLayout
//		flContent.addView(text);
		setSlidingMenuEnable(true);// with slide bar 

		String cache = CacheUtils.getCache(GlobalConstants.CATEGORIES_URL,
				mActivity);

		if (!TextUtils.isEmpty(cache)) {// if cache exists,load the data first
			parseData(cache);
		}

		getDataFromServer();//no matter if there are cache, always visit server to update
	}

	/**
	 * get raw data(raw json) from server
	 */
	private void getDataFromServer() {
		
		// XUtils
		HttpUtils utils = new HttpUtils();

		// XUtils send to get the json string (run in another thread)
		utils.send(HttpMethod.GET, GlobalConstants.CATEGORIES_URL,
				new RequestCallBack<String>() { //json is a String

					// call success (run main thread)
					@Override
					public void onSuccess(ResponseInfo responseInfo) {
						//ResponseInfo responseInfo cannot be run over 6.0
						String result = (String) responseInfo.result;
						System.out.println("raw result:" + result);
		
						parseData(result);
						
						// after parsing data, set latest 
						CacheUtils.setCache(GlobalConstants.CATEGORIES_URL,
								result, mActivity);
					}

					// call fail (run main thread)
					@Override
					public void onFailure(HttpException error, String msg) {
						Toast.makeText(mActivity, msg, Toast.LENGTH_SHORT)
								.show();
						error.printStackTrace();
					}

				});
	}

	/**
	 * parse the raw json String obtained from the server
	 * 
	 * using Gson tool to automatically encapsulate 
	 * @param result
	 */
	protected void parseData(String result) {
		
		Gson gson = new Gson();
		
		//fromJson() can automatically encapsulate the data to a class
		mNewsData = gson.fromJson(result, NewsData.class);
		System.out.println("final result:" + mNewsData);

		// refresh the data of the side bar
		MainActivity mainUi = (MainActivity) mActivity;
		LeftMenuFragment leftMenuFragment = mainUi.getLeftMenuFragment();
		leftMenuFragment.setMenuData(mNewsData);

		// set 4 news page sub window (based on json received from server)
		subNewsPagers = new ArrayList<BaseMenuDetailPager>();
		subNewsPagers.add(new NewsMenuDetailPager(mActivity, mNewsData.data.get(0).children));//,
//				mNewsData.data.get(0).children));
		subNewsPagers.add(new TopicMenuDetailPager(mActivity));
		subNewsPagers.add(new PhotoMenuDetailPager(mActivity, btnPhoto)); //give btnPhoto to sub
		subNewsPagers.add(new InteractMenuDetailPager(mActivity));

		//set sub-window menu information, news(NO.0) is the default one
		setCurrentMenuDetailPager(0);
	}

	/**
	 * set sub-window menu
	 * 
	 * @param position: which sub window
	 */
	public void setCurrentMenuDetailPager(int position) {
		BaseMenuDetailPager pager = subNewsPagers.get(position);// obtain the current sub-window
		
		//------set view------
		//"flContent" is the view for sub-window part
		flContent.removeAllViews();// remove previous contents
		flContent.addView(pager.mRootView);// add selected sub view to the window area

		//------set data------
		// set current sub window's title
		NewsMenuData menuData = mNewsData.data.get(position);
		tvTitle.setText(menuData.title);

		pager.initData();// initialize sub window data
		
		//only if current pager is PhotoMenuDetailPager do we show change icon
		if (pager instanceof PhotoMenuDetailPager) {
			btnPhoto.setVisibility(View.VISIBLE);
		} else {
			btnPhoto.setVisibility(View.GONE);
		}
	}

}
